#!/bin/bash
# Start the Java API application
echo "Starting the currency-exchange-api application"
systemctl start currency-exchange-api.service
