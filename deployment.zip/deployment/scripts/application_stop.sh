#!/bin/bash
# Stop the Java API application
echo "Stopping the currency-exchange-api application"
systemctl stop currency-exchange-api.service
